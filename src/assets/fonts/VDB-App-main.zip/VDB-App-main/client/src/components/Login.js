import React from 'react';

const Login = () => ('Hello')

export default Login;