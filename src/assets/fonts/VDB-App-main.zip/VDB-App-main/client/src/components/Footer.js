import React from "react";

const Footer = () => {
  return (
    <footer>
      <div>
        <h4 className="footerText">Made by the IVDB team ❤️</h4>
      </div>
    </footer>
  );
};

export default Footer;
