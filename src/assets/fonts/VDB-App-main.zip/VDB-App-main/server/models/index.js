const User = require('./User');
const Game = require('./Game');
const GameList = require('./GameList')

module.exports = { User, Game, GameList };
